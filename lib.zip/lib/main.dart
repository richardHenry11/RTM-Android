import 'package:flutter/material.dart';
import 'package:rtm/dashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'login.dart';
import 'package:rtm/connection/socket_service.dart';
import 'dart:async';
import 'dashboard.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences prefs = await SharedPreferences.getInstance();

  // Periksa apakah nilai null atau bukan boolean
  bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

  runApp(MyApp(isLoggedIn: isLoggedIn));
}


class MyApp extends StatelessWidget {
  final bool isLoggedIn;
  MyApp({required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: isLoggedIn ? MainPage() : LoginPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final socketService = SocketService();
  bool _isloadloading = false;
  bool _hasNavigated = false;
  Timer? snackbarTimer;

@override
void initState() {
  super.initState();
  print("📡 inittialization websocket...");

  socketService.onStatusChange = (status) {
    print("🛜 WebSocket Status: $status");

    if (!mounted) return; // Pastikan widget masih ada sebelum update UI

    if (status == "connected") {
      print("connected to websocket");
    } else {
      print("disconnected");
    }
  };

  // Panggil koneksi WebSocket
  socketService.connect();
}



  Future<void> _logout() async {
    setState(() {
      _isloadloading = true;
    });

    String email = "email";
    String password = "password";
    String logout = "logout";

    final response = await http.post(
      Uri.parse('https://rtmonitor.mdtapps.id/api/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password, 'type': logout}),
    );

    setState(() {
      _isloadloading = false;
    });

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      if (data['status'] == 'Logged out') {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.clear(); // Menghapus semua data user agar lebih bersih

        print(response.body);
        print("Logout successful");

        if (!context.mounted) return; // Pastikan context masih ada sebelum navigasi

        // Pindah ke halaman login tanpa bisa kembali
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      }
    }
  }

  @override
  void dispose() {
    snackbarTimer?.cancel(); // Hentikan timer saat widget dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF28ABEA),
        title: Image.asset('assets/logo.png', height: 40, width: 200,),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,
          )
        ],
      ),
      body: 
      Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/bg.png"),
            fit: BoxFit.cover,
          )
        ),
        child: Column(
          children: [
            Center(child: Text("")),
            ElevatedButton(onPressed: (){
              Navigator.push(context, 
                MaterialPageRoute(builder: (context) => Dashboard())
              );
            },
            child: Text("pembacaan"))
          ],
        ),
      ),
    );
  }
}