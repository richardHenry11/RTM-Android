import 'package:flutter/material.dart';
// import 'dashboard.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'main.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  Future<void> _login() async {
    setState(() {
      _isLoading = true;
    });

    String email = _usernameController.text;
    String password = _passwordController.text;
    String login = "login";

    final response = await http.post(
      Uri.parse('https://rtmonitor.mdtapps.id/api/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password, 'type':login}),
    )
    .timeout(Duration(seconds: 10));

    setState(() {
      _isLoading = false;
    });

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      
      if (data['status'] == 'OK' && data['role'] == 'admin') {
        print("Login Successful, Role: ${data['role']}");

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Login Berhasil!"),
            backgroundColor: Colors.green,
          ),
        );

        // Simpan data login
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('role', data['role']);
        await prefs.setBool('isLoggedIn', true);

        // Pindah ke halaman utama
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => MainPage()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Login Failed: ${data['status']}")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("failed to connect to server")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF28ABEA),
      body: 
      Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Login", style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800),
            ),
            SizedBox(
              height: 50,
              ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: 
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(labelText: "Email",
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(50),
                              borderSide: BorderSide.none
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.circular(50)
                            ), 
                            filled: true,
                            fillColor: Colors.white      
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: 
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: "Password",
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(50),
                              borderSide: BorderSide.none
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius: BorderRadius.circular(50)
                            ), 
                            filled: true,
                            fillColor: Colors.white      
                ),
              ),
            ),
            SizedBox(height: 50),
            _isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF474443)),
                    onPressed: _login,
                    child: Text("Login", style: TextStyle(color: Colors.white),),
                  ),
          ],
        ),
      ),
    );
  }
}
