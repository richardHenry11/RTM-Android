import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rtm/connection/socket_service.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final socketService = SocketService();
  final TextEditingController _controller = TextEditingController();
  final List<String> _items = [];
  String? _selectedItems;
  String? _email;

  // Data from websocket
  List<String> devicesId = [];
  List<String> devicesName = [];
  Map<String, String> deviceStatus = {}; // key: device_id, Value: running_time

  void sendMessageToWS() {
    if (_selectedItems == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Pilih site terlebih dahulu berdasarkan dropdown")),
      );
      return;
    }

    Map<String, dynamic> message = {
      "email": _email,
      "site_id": _selectedItems,
    };

    print("📡 Sending message to WebSocket: $message");
    socketService.sendMessage(jsonEncode(message));
  }

  void _handleWebsocketResponse(dynamic message) {
    try {
      Map<String, dynamic> data = jsonDecode(message);

      List<dynamic> deviceIds = data["device_id"] is List ? data["device_id"] : [];
      List<dynamic> deviceNames = data["device_name"] is List ? data["device_name"] : [];
      // List<dynamic> runningTimes = data["running_time"] is List ? data["running_time"] : [];
      List<dynamic> runningTimes = data.containsKey("running_time") && data["running_time"] is List
        ? data["running_time"]
        : List.filled(deviceIds.length, "00:00:00"); // Default jika kosong

        print("Data received: deviceIds=${deviceIds.length}, deviceNames=${deviceNames.length}, runningTimes=${runningTimes.length}");

      int minLength = [deviceIds.length, deviceNames.length, runningTimes.length]
          .reduce((a, b) => a < b ? a : b);

      setState(() {
        devicesId.clear();
        devicesName.clear();
        deviceStatus.clear();

        for (int i = 0; i < minLength; i++) {
          String deviceId = deviceIds[i]?.toString() ?? "Unknown";
          String deviceName = deviceNames[i]?.toString() ?? "Unknown";
          String runningTime = runningTimes[i]?.toString() ?? "00:00:00";

          devicesId.add(deviceId);
          devicesName.add(deviceName);
          deviceStatus[deviceId] = runningTime;
        }
      });

      print("final parsed data: devicesId = $devicesId, devicesName = $deviceNames, deviceStatus = $deviceStatus");

    } catch (e, stackTrace) {
      print("❌ Error parsing WebSocket response: $e");
      print(stackTrace);
    }
  }

  @override
  void initState() {
    super.initState();
    _loadEmail();

    print("📡 Initializing WebSocket...");

    bool isReconnecting = false;

    socketService.onStatusChange = (status) {
      print("🛜 WebSocket Status: $status");

      if (!mounted) return;

      if (status == "connected") {
        print("✅ Connected to WebSocket");
        isReconnecting = false;
      } else if (status == "disconnected" && !isReconnecting) {
        isReconnecting = true;
        print("⚠️ WebSocket Disconnected, retrying in 5 seconds...");

        Future.delayed(Duration(seconds: 5), () {
          if (mounted && socketService.status != "connected") {
            print("🔄 Attempting to reconnect...");
            socketService.connect();
          }
          isReconnecting = false;
        });
      }
    };

    socketService.connect();
    // socketService.onMessageReceived = _handleWebsocketResponse;
    // Tangani pesan dari WebSocket
  socketService.onMessageReceived = (message) {
    print("🛜 WebSocket Message: $message"); // Debug log
    _handleWebsocketResponse(message);
  };
  }

  Future<void> _loadEmail() async {
    final pref = await SharedPreferences.getInstance();
    setState(() {
      _email = pref.getString('email') ?? 'admin@rtm.envilife.id';
    });
  }

  Future<void> _reader() async {
    if (_email == null) {
      print("⚠️ Email belum dimuat, coba lagi...");
      return;
    }

    print("📡 Menghubungkan ke API...");

    final response = await http.post(
      Uri.parse('https://rtmonitor.mdtapps.id/api/data'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': _email, 'type': 'site_id'}),
    );

    print("🛜 Response API: ${response.statusCode}");

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      print("✅ Data diterima: $data");

      if (data['site_id'] != null) {
        setState(() {
          _items.clear();
          _items.addAll(List<String>.from(data['site_id']));
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Realtime Monitoring", style: TextStyle(color: Colors.white)),
        backgroundColor: Color(0xFF28ABEA),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              "Real Time Monitoring",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5))),
                onPressed: () async {
                  await _reader();
                },
                child: Text("Show Devices List"),
              ),
              ElevatedButton(
                onPressed: sendMessageToWS,
                child: Text("Get Devices"),
              ),
            ],
          ),
          Stack(
            children: [
              TextFormField(
                enabled: false,
                controller: _controller,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(horizontal: 10),
                ),
              ),
              Positioned(
                right: 0,
                child: PopupMenuButton<String>(
                  icon: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.blueGrey.shade900,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(4),
                        bottomRight: Radius.circular(4),
                      ),
                    ),
                    child: Icon(Icons.arrow_drop_down, color: Colors.white),
                  ),
                  onSelected: (String value) {
                    setState(() {
                      _controller.text = value;
                      _selectedItems = value;
                    });
                  },
                  itemBuilder: (BuildContext context) {
                    return _items.map((String item) {
                      return PopupMenuItem<String>(
                        value: item,
                        child: Text(item),
                      );
                    }).toList();
                  },
                ),
              ),
            ],
          ),
          Expanded(
            child: devicesId.isEmpty
                ? Center(child: Text("No Devices Available"))
                : ListView.builder(
                    itemCount: devicesId.length,
                    itemBuilder: (context, index) {
                      if(index >= devicesId.length || index >= devicesName.length){
                        return SizedBox();
                      }
                      String deviceId = devicesId[index];
                      String runningTime = deviceStatus[deviceId] ?? "00.00.00";
                      String deviceName = devicesName[index];

                      return Card(
                        margin: EdgeInsets.all(8.0),
                        elevation: 4,
                        child: ListTile(
                          title: Text(deviceName),
                          subtitle: 
                          // Text("ID: $deviceId\nTime: $runningTime"), 
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("ID: $deviceId"),
                              Text("Time: $runningTime"),
                            ],
                          ),
                          leading: Icon(Icons.devices, color: Colors.blue),
                        ),
                      );
                    },
                  ),
          )
        ],
      ),
    );
  }
}
